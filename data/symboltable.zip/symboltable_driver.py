st = SymbolTable()




st.StackDump()
